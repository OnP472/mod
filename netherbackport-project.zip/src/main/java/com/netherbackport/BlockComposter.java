package com.netherbackport;

import net.minecraft.block.Block;
import net.minecraft.block.BlockFlower;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.BlockSapling;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.Random;

public class BlockComposter extends Block {
    public static final PropertyInteger LEVEL = PropertyInteger.create("level", 0, 8);

    public BlockComposter() {
        super(Material.WOOD);
        setSoundType(SoundType.WOOD);
        setDefaultState(blockState.getBaseState().withProperty(LEVEL, 0));
    }

    @Override
    protected BlockStateContainer createBlockState() {
        return new BlockStateContainer(this, LEVEL);
    }

    @Override
    public IBlockState getStateFromMeta(int meta) {
        return getDefaultState().withProperty(LEVEL, Math.min(meta, 8));
    }

    @Override
    public int getMetaFromState(IBlockState state) {
        return state.getValue(LEVEL);
    }

    @Override
    public boolean isOpaqueCube(IBlockState state) {
        return false;
    }

    @Override
    public boolean isFullCube(IBlockState state) {
        return false;
    }

    private static float chance(ItemStack stack) {
        if (stack.isEmpty()) return 0.0F;
        Item item = stack.getItem();
        Block block = Block.getBlockFromItem(item);
        if (item == Items.WHEAT_SEEDS || item == Items.MELON_SEEDS || item == Items.PUMPKIN_SEEDS || item == Items.BEETROOT_SEEDS) return 0.3F;
        if (block instanceof BlockSapling || block instanceof BlockLeaves || block == Blocks.TALLGRASS) return 0.3F;
        if (item == Items.MELON || item == Items.REEDS || block == Blocks.VINE || block == Blocks.CACTUS) return 0.5F;
        if (item == Items.APPLE || item == Items.CARROT || item == Items.POTATO || item == Items.BEETROOT || item == Items.WHEAT) return 0.65F;
        if (block instanceof BlockFlower || block == Blocks.BROWN_MUSHROOM || block == Blocks.RED_MUSHROOM) return 0.65F;
        if (item == Items.BAKED_POTATO || item == Items.BREAD || item == Items.COOKIE || block == Blocks.HAY_BLOCK) return 0.85F;
        if (item == Items.CAKE || item == Items.PUMPKIN_PIE || block == Blocks.MELON_BLOCK || block == Blocks.PUMPKIN) return 1.0F;
        return 0.0F;
    }

    @Override
    public boolean onBlockActivated(World world, BlockPos pos, IBlockState state, EntityPlayer player, EnumHand hand,
                                    EnumFacing side, float hitX, float hitY, float hitZ) {
        int level = state.getValue(LEVEL);
        ItemStack held = player.getHeldItem(hand);
        if (level == 8) {
            if (!world.isRemote) {
                InventoryHelper.spawnItemStack(world, pos.getX() + 0.5D, pos.getY() + 1.05D, pos.getZ() + 0.5D, new ItemStack(Items.DYE, 1, 15));
                world.setBlockState(pos, state.withProperty(LEVEL, 0), 3);
            }
            return true;
        }
        if (level < 7) {
            float c = chance(held);
            if (c > 0.0F) {
                if (!world.isRemote) {
                    if (level == 0 || world.rand.nextFloat() < c) {
                        world.setBlockState(pos, state.withProperty(LEVEL, level + 1), 3);
                        if (level + 1 == 7) world.scheduleUpdate(pos, this, 20);
                    }
                    if (!player.capabilities.isCreativeMode) held.shrink(1);
                }
                return true;
            }
        }
        return false;
    }

    @Override
    public void updateTick(World world, BlockPos pos, IBlockState state, Random rand) {
        if (!world.isRemote && state.getValue(LEVEL) == 7) {
            world.setBlockState(pos, state.withProperty(LEVEL, 8), 3);
        }
    }
}
