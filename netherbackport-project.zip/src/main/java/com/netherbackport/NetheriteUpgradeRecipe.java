package com.netherbackport;

import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.util.NonNullList;
import net.minecraft.world.World;
import net.minecraftforge.registries.IForgeRegistryEntry;

/** Diamond item + Netherite Ingot -> Netherite item, keeping enchantments and name (like the 1.16 smithing table). */
public class NetheriteUpgradeRecipe extends IForgeRegistryEntry.Impl<IRecipe> implements IRecipe {
    private final Item base;
    private final Item result;

    public NetheriteUpgradeRecipe(Item base, Item result) {
        this.base = base;
        this.result = result;
    }

    @Override
    public boolean matches(InventoryCrafting inv, World world) {
        boolean hasBase = false, hasIngot = false;
        for (int i = 0; i < inv.getSizeInventory(); i++) {
            ItemStack s = inv.getStackInSlot(i);
            if (s.isEmpty()) continue;
            if (s.getItem() == base && !hasBase) hasBase = true;
            else if (s.getItem() == ModItems.NETHERITE_INGOT && !hasIngot) hasIngot = true;
            else return false;
        }
        return hasBase && hasIngot;
    }

    @Override
    public ItemStack getCraftingResult(InventoryCrafting inv) {
        ItemStack out = new ItemStack(result);
        for (int i = 0; i < inv.getSizeInventory(); i++) {
            ItemStack s = inv.getStackInSlot(i);
            if (s.getItem() == base) {
                if (s.hasTagCompound()) out.setTagCompound(s.getTagCompound().copy());
                if (s.getMaxDamage() > 0 && out.getMaxDamage() > 0) {
                    float ratio = (float) s.getItemDamage() / s.getMaxDamage();
                    out.setItemDamage(Math.min(out.getMaxDamage() - 1, Math.round(ratio * out.getMaxDamage())));
                }
                break;
            }
        }
        return out;
    }

    @Override
    public boolean canFit(int width, int height) {
        return width * height >= 2;
    }

    @Override
    public ItemStack getRecipeOutput() {
        return new ItemStack(result);
    }

    @Override
    public NonNullList<Ingredient> getIngredients() {
        return NonNullList.from(Ingredient.EMPTY, Ingredient.fromItems(base), Ingredient.fromItems(ModItems.NETHERITE_INGOT));
    }
}
