package com.netherbackport;

import net.minecraft.block.BlockRotatedPillar;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;

public class BlockStrippedLog extends BlockRotatedPillar {
    public BlockStrippedLog() {
        super(Material.WOOD);
        setSoundType(SoundType.WOOD);
    }
}
