package com.netherbackport;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.registry.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

/** Unlocks every modded recipe in the recipe book when a player joins, so they show up and can be clicked to craft. */
public class RecipeUnlocker {
    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.player instanceof EntityPlayerMP)) return;
        List<IRecipe> modded = new ArrayList<>();
        for (IRecipe recipe : ForgeRegistries.RECIPES.getValuesCollection()) {
            ResourceLocation name = recipe.getRegistryName();
            if (name != null && !"minecraft".equals(name.getResourceDomain()) && !recipe.getRecipeOutput().isEmpty()) {
                modded.add(recipe);
            }
        }
        ((EntityPlayerMP) event.player).unlockRecipes(modded);
    }
}
