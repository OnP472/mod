package com.netherbackport;

import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraftforge.common.util.EnumHelper;

public class ModMaterials {
    // harvest level, durability, efficiency, attack damage bonus, enchantability
    public static final Item.ToolMaterial NETHERITE_TOOL =
            EnumHelper.addToolMaterial("NETHERITE", 4, 2031, 9.0F, 4.0F, 15);

    // texture name, durability multiplier, reduction {boots, leggings, chest, helmet}, enchantability, sound, toughness
    public static final ItemArmor.ArmorMaterial NETHERITE_ARMOR =
            EnumHelper.addArmorMaterial("NETHERITE", NetherBackport.MODID + ":netherite", 37,
                    new int[]{3, 6, 8, 3}, 15, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 3.0F);
}
