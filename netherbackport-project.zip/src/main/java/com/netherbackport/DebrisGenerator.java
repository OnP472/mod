package com.netherbackport;

import net.minecraft.init.Blocks;
import net.minecraft.block.state.pattern.BlockMatcher;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraftforge.fml.common.IWorldGenerator;

import java.util.Random;

public class DebrisGenerator implements IWorldGenerator {
    private final WorldGenMinable deepVein = new WorldGenMinable(
            ModBlocks.ANCIENT_DEBRIS.getDefaultState(), 3, BlockMatcher.forBlock(Blocks.NETHERRACK));
    private final WorldGenMinable wideVein = new WorldGenMinable(
            ModBlocks.ANCIENT_DEBRIS.getDefaultState(), 2, BlockMatcher.forBlock(Blocks.NETHERRACK));

    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator generator, IChunkProvider provider) {
        if (world.provider.getDimension() != -1) return; // Nether only
        deepVein.generate(world, random, pos(random, chunkX, chunkZ, 8, 15));   // y 8-22
        wideVein.generate(world, random, pos(random, chunkX, chunkZ, 8, 112));  // y 8-119
    }

    private BlockPos pos(Random random, int chunkX, int chunkZ, int minY, int range) {
        return new BlockPos(chunkX * 16 + 8 + random.nextInt(16), minY + random.nextInt(range), chunkZ * 16 + 8 + random.nextInt(16));
    }
}
