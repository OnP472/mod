package com.netherbackport;

import net.minecraft.tileentity.TileEntityChest;

/** 27-slot storage (like a chest, but never joins into a double chest). */
public class TileEntityBarrel extends TileEntityChest {
    @Override
    public String getName() {
        return this.hasCustomName() ? super.getName() : "container.barrel";
    }
}
