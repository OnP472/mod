package com.netherbackport;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod(modid = NetherBackport.MODID, name = NetherBackport.NAME, version = NetherBackport.VERSION, acceptedMinecraftVersions = "[1.12.2]")
public class NetherBackport {
    public static final String MODID = "netherbackport";
    public static final String NAME = "Nether Backport";
    public static final String VERSION = "1.0.0";

    public static final CreativeTabs TAB = new CreativeTabs(MODID) {
        @Override
        public ItemStack getTabIconItem() {
            return new ItemStack(ModItems.NETHERITE_INGOT);
        }
    };

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        GameRegistry.registerWorldGenerator(new DebrisGenerator(), 0);
        MinecraftForge.EVENT_BUS.register(new FireproofHandler());
        MinecraftForge.EVENT_BUS.register(new RecipeUnlocker());
        MinecraftForge.EVENT_BUS.register(new StripHandler());
        GameRegistry.registerTileEntity(TileEntityBarrel.class, new ResourceLocation(MODID, "barrel"));
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        ItemStack ingot = new ItemStack(ModItems.NETHERITE_INGOT);
        ModMaterials.NETHERITE_TOOL.setRepairItem(ingot);
        ModMaterials.NETHERITE_ARMOR.setRepairItem(ingot);
        GameRegistry.addSmelting(ModBlocks.ANCIENT_DEBRIS, new ItemStack(ModItems.NETHERITE_SCRAP), 2.0F);
    }
}
