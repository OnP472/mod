package com.netherbackport;

import com.google.common.collect.Multimap;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;

import java.util.UUID;

public class ItemNetheriteArmor extends ItemArmor {
    // index = EntityEquipmentSlot.getIndex(): feet, legs, chest, head
    private static final UUID[] KB_UUIDS = {
            UUID.fromString("3c1a5e10-7a3b-4c55-9d0e-1f2b7a6c0001"),
            UUID.fromString("3c1a5e10-7a3b-4c55-9d0e-1f2b7a6c0002"),
            UUID.fromString("3c1a5e10-7a3b-4c55-9d0e-1f2b7a6c0003"),
            UUID.fromString("3c1a5e10-7a3b-4c55-9d0e-1f2b7a6c0004")
    };

    public ItemNetheriteArmor(EntityEquipmentSlot slot) {
        super(ModMaterials.NETHERITE_ARMOR, 0, slot);
    }

    @Override
    public Multimap<String, AttributeModifier> getItemAttributeModifiers(EntityEquipmentSlot slot) {
        Multimap<String, AttributeModifier> map = super.getItemAttributeModifiers(slot);
        if (slot == this.armorType) {
            map.put(SharedMonsterAttributes.KNOCKBACK_RESISTANCE.getName(),
                    new AttributeModifier(KB_UUIDS[slot.getIndex()], "Knockback resistance", 0.1D, 0));
        }
        return map;
    }
}
