package com.netherbackport;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = NetherBackport.MODID)
public class ModBlocks {
    public static final List<Block> ALL = new ArrayList<>(); // must stay first

    // setResistance() multiplies by 3 internally: 400 -> blast resistance 1200
    public static final Block ANCIENT_DEBRIS = harvest(add(new Block(Material.IRON), "ancient_debris", 30.0F, 400.0F, SoundType.METAL), "pickaxe", 3);
    public static final Block NETHERITE_BLOCK = harvest(add(new Block(Material.IRON), "netherite_block", 50.0F, 400.0F, SoundType.METAL), "pickaxe", 3);

    public static final Block BLUE_ICE = slippery(add(new Block(Material.PACKED_ICE), "blue_ice", 2.8F, 2.8F, SoundType.GLASS));

    public static final Block STRIPPED_OAK_LOG = add(new BlockStrippedLog(), "stripped_oak_log", 2.0F, 3.0F, SoundType.WOOD);
    public static final Block STRIPPED_SPRUCE_LOG = add(new BlockStrippedLog(), "stripped_spruce_log", 2.0F, 3.0F, SoundType.WOOD);
    public static final Block STRIPPED_BIRCH_LOG = add(new BlockStrippedLog(), "stripped_birch_log", 2.0F, 3.0F, SoundType.WOOD);
    public static final Block STRIPPED_JUNGLE_LOG = add(new BlockStrippedLog(), "stripped_jungle_log", 2.0F, 3.0F, SoundType.WOOD);
    public static final Block STRIPPED_ACACIA_LOG = add(new BlockStrippedLog(), "stripped_acacia_log", 2.0F, 3.0F, SoundType.WOOD);
    public static final Block STRIPPED_DARK_OAK_LOG = add(new BlockStrippedLog(), "stripped_dark_oak_log", 2.0F, 3.0F, SoundType.WOOD);

    // workstations (decorative for now, no screen yet)
    public static final Block SMITHING_TABLE = add(new BlockFacing(Material.WOOD), "smithing_table", 2.5F, 2.5F, SoundType.WOOD);
    public static final Block FLETCHING_TABLE = add(new BlockFacing(Material.WOOD), "fletching_table", 2.5F, 2.5F, SoundType.WOOD);
    public static final Block CARTOGRAPHY_TABLE = add(new BlockFacing(Material.WOOD), "cartography_table", 2.5F, 2.5F, SoundType.WOOD);
    public static final Block LOOM = add(new BlockFacing(Material.WOOD), "loom", 2.5F, 2.5F, SoundType.WOOD);
    public static final Block LECTERN = add(new BlockFacing(Material.WOOD, false, new AxisAlignedBB(0, 0, 0, 1, 14.0D / 16.0D, 1)), "lectern", 2.5F, 2.5F, SoundType.WOOD);
    public static final Block STONECUTTER = harvest(add(new BlockFacing(Material.ROCK, false, new AxisAlignedBB(0, 0, 0, 1, 9.0D / 16.0D, 1)), "stonecutter", 3.5F, 3.5F, SoundType.STONE), "pickaxe", 0);
    public static final Block SMOKER = harvest(add(new BlockFacing(Material.ROCK), "smoker", 3.5F, 3.5F, SoundType.STONE), "pickaxe", 0);
    public static final Block BLAST_FURNACE = harvest(add(new BlockFacing(Material.ROCK), "blast_furnace", 3.5F, 3.5F, SoundType.STONE), "pickaxe", 0);

    // working blocks
    public static final Block BARREL = add(new BlockBarrel(), "barrel", 2.5F, 2.5F, SoundType.WOOD);
    public static final Block COMPOSTER = add(new BlockComposter(), "composter", 0.6F, 0.6F, SoundType.WOOD);

    private static <T extends Block> T add(T block, String name, float hardness, float resistance, SoundType sound) {
        block.setRegistryName(NetherBackport.MODID, name);
        block.setUnlocalizedName(NetherBackport.MODID + "." + name);
        block.setCreativeTab(NetherBackport.TAB);
        block.setHardness(hardness);
        block.setResistance(resistance);
        block.setSoundType(sound);
        ALL.add(block);
        return block;
    }

    private static <T extends Block> T harvest(T block, String tool, int level) {
        block.setHarvestLevel(tool, level);
        return block;
    }

    private static <T extends Block> T slippery(T block) {
        block.slipperiness = 0.989F;
        return block;
    }

    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        event.getRegistry().registerAll(ALL.toArray(new Block[0]));
    }
}
