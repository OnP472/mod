package com.netherbackport;

import net.minecraft.block.Block;
import net.minecraft.block.BlockLog;
import net.minecraft.block.BlockNewLog;
import net.minecraft.block.BlockOldLog;
import net.minecraft.block.BlockRotatedPillar;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Right-click a log with any axe to strip it (like 1.13+). */
public class StripHandler {
    @SubscribeEvent
    public void onRightClick(PlayerInteractEvent.RightClickBlock event) {
        ItemStack held = event.getItemStack();
        if (!(held.getItem() instanceof ItemAxe)) return;
        World world = event.getWorld();
        BlockPos pos = event.getPos();
        IBlockState state = world.getBlockState(pos);
        Block stripped = strippedFor(state);
        if (stripped == null) return;

        EnumFacing.Axis axis;
        switch (state.getValue(BlockLog.LOG_AXIS)) {
            case X: axis = EnumFacing.Axis.X; break;
            case Z: axis = EnumFacing.Axis.Z; break;
            default: axis = EnumFacing.Axis.Y; break;
        }
        if (!world.isRemote) {
            world.setBlockState(pos, stripped.getDefaultState().withProperty(BlockRotatedPillar.AXIS, axis), 11);
            held.damageItem(1, event.getEntityPlayer());
        }
        world.playSound(event.getEntityPlayer(), pos, SoundEvents.BLOCK_WOOD_BREAK, SoundCategory.BLOCKS, 1.0F, 0.8F);
        event.getEntityPlayer().swingArm(event.getHand());
        event.setCanceled(true);
    }

    private static Block strippedFor(IBlockState state) {
        Block block = state.getBlock();
        if (block == Blocks.LOG) {
            switch (state.getValue(BlockOldLog.VARIANT)) {
                case OAK: return ModBlocks.STRIPPED_OAK_LOG;
                case SPRUCE: return ModBlocks.STRIPPED_SPRUCE_LOG;
                case BIRCH: return ModBlocks.STRIPPED_BIRCH_LOG;
                case JUNGLE: return ModBlocks.STRIPPED_JUNGLE_LOG;
                default: return null;
            }
        }
        if (block == Blocks.LOG2) {
            switch (state.getValue(BlockNewLog.VARIANT)) {
                case ACACIA: return ModBlocks.STRIPPED_ACACIA_LOG;
                case DARK_OAK: return ModBlocks.STRIPPED_DARK_OAK_LOG;
                default: return null;
            }
        }
        return null;
    }
}
