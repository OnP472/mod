package com.netherbackport;

import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.*;
import net.minecraft.item.crafting.IRecipe;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = NetherBackport.MODID)
public class ModItems {
    public static final List<Item> ALL = new ArrayList<>(); // must stay first

    public static final Item NETHERITE_SCRAP = item(new Item(), "netherite_scrap");
    public static final Item NETHERITE_INGOT = item(new Item(), "netherite_ingot");

    public static final Item NETHERITE_SWORD = item(new ItemSword(ModMaterials.NETHERITE_TOOL), "netherite_sword");
    public static final Item NETHERITE_PICKAXE = item(new ItemNetheritePickaxe(ModMaterials.NETHERITE_TOOL), "netherite_pickaxe");
    public static final Item NETHERITE_AXE = item(new ItemNetheriteAxe(ModMaterials.NETHERITE_TOOL), "netherite_axe");
    public static final Item NETHERITE_SHOVEL = item(new ItemSpade(ModMaterials.NETHERITE_TOOL), "netherite_shovel");
    public static final Item NETHERITE_HOE = item(new ItemHoe(ModMaterials.NETHERITE_TOOL), "netherite_hoe");

    public static final Item NETHERITE_HELMET = item(new ItemNetheriteArmor(EntityEquipmentSlot.HEAD), "netherite_helmet");
    public static final Item NETHERITE_CHESTPLATE = item(new ItemNetheriteArmor(EntityEquipmentSlot.CHEST), "netherite_chestplate");
    public static final Item NETHERITE_LEGGINGS = item(new ItemNetheriteArmor(EntityEquipmentSlot.LEGS), "netherite_leggings");
    public static final Item NETHERITE_BOOTS = item(new ItemNetheriteArmor(EntityEquipmentSlot.FEET), "netherite_boots");

    static {
        for (net.minecraft.block.Block block : ModBlocks.ALL) {
            blockItem(block);
        }
    }

    private static Item item(Item item, String name) {
        item.setRegistryName(NetherBackport.MODID, name);
        item.setUnlocalizedName(NetherBackport.MODID + "." + name);
        item.setCreativeTab(NetherBackport.TAB);
        ALL.add(item);
        return item;
    }

    private static Item blockItem(net.minecraft.block.Block block) {
        Item item = new ItemBlock(block);
        item.setRegistryName(block.getRegistryName());
        ALL.add(item);
        return item;
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(ALL.toArray(new Item[0]));
    }

    @SubscribeEvent
    public static void registerRecipes(RegistryEvent.Register<IRecipe> event) {
        upgrade(event, Items.DIAMOND_SWORD, NETHERITE_SWORD, "sword");
        upgrade(event, Items.DIAMOND_PICKAXE, NETHERITE_PICKAXE, "pickaxe");
        upgrade(event, Items.DIAMOND_AXE, NETHERITE_AXE, "axe");
        upgrade(event, Items.DIAMOND_SHOVEL, NETHERITE_SHOVEL, "shovel");
        upgrade(event, Items.DIAMOND_HOE, NETHERITE_HOE, "hoe");
        upgrade(event, Items.DIAMOND_HELMET, NETHERITE_HELMET, "helmet");
        upgrade(event, Items.DIAMOND_CHESTPLATE, NETHERITE_CHESTPLATE, "chestplate");
        upgrade(event, Items.DIAMOND_LEGGINGS, NETHERITE_LEGGINGS, "leggings");
        upgrade(event, Items.DIAMOND_BOOTS, NETHERITE_BOOTS, "boots");
    }

    private static void upgrade(RegistryEvent.Register<IRecipe> event, Item from, Item to, String name) {
        NetheriteUpgradeRecipe recipe = new NetheriteUpgradeRecipe(from, to);
        recipe.setRegistryName(NetherBackport.MODID, "upgrade_" + name);
        event.getRegistry().register(recipe);
    }
}
