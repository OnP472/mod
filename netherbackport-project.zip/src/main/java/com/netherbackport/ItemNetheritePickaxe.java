package com.netherbackport;

import net.minecraft.item.ItemPickaxe;

public class ItemNetheritePickaxe extends ItemPickaxe {
    public ItemNetheritePickaxe(ToolMaterial material) {
        super(material);
    }
}
