package com.netherbackport;

import net.minecraft.entity.item.EntityItem;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Dropped items from this mod survive lava and fire (void still destroys them). */
public class FireproofHandler {
    @SubscribeEvent
    public void onJoin(EntityJoinWorldEvent event) {
        if (event.getEntity() instanceof EntityItem) {
            EntityItem drop = (EntityItem) event.getEntity();
            ResourceLocation name = drop.getItem().getItem().getRegistryName();
            if (name != null && NetherBackport.MODID.equals(name.getResourceDomain())) {
                drop.setEntityInvulnerable(true);
            }
        }
    }
}
