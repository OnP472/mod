package com.netherbackport;

import net.minecraft.item.ItemAxe;

public class ItemNetheriteAxe extends ItemAxe {
    public ItemNetheriteAxe(ToolMaterial material) {
        // explicit damage/speed: the 1-arg constructor indexes vanilla arrays by enum ordinal and would crash
        super(material, 9.0F, -3.0F);
    }
}
